#include "Point.h"

DRAGONBONES_NAMESPACE_BEGIN

Point Point::helpPointA;
Point Point::helpPointB;
Point Point::helpPointC;
Point Point::helpPointD;

DRAGONBONES_NAMESPACE_END
