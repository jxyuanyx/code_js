export  enum LoginType{
    Account,            //帐号密码登陆
    Facebook,           //facebook登陆
    Guest               //游客    
}

export enum LoginAction{
    Reg,                //注册
    Login               //登陆    
}