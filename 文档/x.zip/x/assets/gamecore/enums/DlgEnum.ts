export enum DlgEnum {
    NONE=1,
    SCALE,
    L2R,
    R2L,
    T2B,
    B2T,
    FADE,

    DOCK_TOP,
    DOCK_BOTTOM,
    DOCK_LEFT,
    DOCK_RIGHT
}