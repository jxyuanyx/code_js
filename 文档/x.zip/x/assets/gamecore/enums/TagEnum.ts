export enum TagEnum{
    NET="Net",
    NET_MESSAGE="Net_Message",
    NET_SEND="Net_Send",

    BUNDLE="bundle",

    DEBUG="debug"
}