export enum NetEnum{
   REP_ROUTE="onData",
   REQ_ROUTE="onSendData",

   REQ_CONTECT="req_connect",

   REQ_LOGIN="req_login"
}