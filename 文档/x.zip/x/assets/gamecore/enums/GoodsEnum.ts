export enum GoodsEnum{
    TICKET = 1,
    CASH = 2,
    BONUSCASH = 3,
    SeasonPoint = 5,
    LOTTERYTICKETLV1 = 6,
    LOTTERYTICKETLV2 = 7,
    LOTTERYTICKETLV3 = 8,
    LOTTERYTICKETLV4 = 9,
    DIAMOND = 10

}
