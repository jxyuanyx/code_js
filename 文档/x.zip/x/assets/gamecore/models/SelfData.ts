export class SelfData{
    account_status:number= 0;
    account_type:number= 10;
    area_code:string="0";
    avatar: string="";
    desk_id: number=0;
    gender:number=2;
    gold:number=0;//总的
    gold_deposit:number= 0;//绑金
    gold_ratio:number=1000;//倍率
    gold_withdraw:number=0;//可提现
    is_register:number=0;
    nick:string="User_3";
    room_id:number=0;
    room_type:number= 0;
    ticket:number= 0;
    signature:string="";
    today_first_login:number=0;
    token:string="";
    uid:number= 3;
    uuid:string="";
    seasons:any;
    progress:number=0;//新手引导的进度
}