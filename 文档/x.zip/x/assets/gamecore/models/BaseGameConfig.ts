export default class BaseGameConfig{
    static mainBundle:string="mainpackage";
    static topTip:cc.Node;
}