export enum CommonNetEnum{
    REQ_ROOMTYPE="match.matchHandler.getRoomType",      //获取房间类型
    REQ_ROOMID ="match.matchHandler.getFreeTable",      //获取房间类型
    REQ_ENTERROOM="game%s.handler.enterRoom",             //进入房间
}