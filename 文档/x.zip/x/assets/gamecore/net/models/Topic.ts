export default class Topic {
    public topic: string;
    public qos: 0 | 1 | 2;
}