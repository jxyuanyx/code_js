export enum LoginCmd{
    LoginByUUid=1000,
    LoginByUserId,
    LoginByToken
}