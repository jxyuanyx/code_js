export enum HallCmd{
    GetHallConfig=2000,
}