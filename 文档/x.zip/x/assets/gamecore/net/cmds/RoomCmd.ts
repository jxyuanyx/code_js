export enum RoomCmd{
    EnterRoom=3000,
    SitDown,
    StandUp,
    ExitRoom,
    SendChat,
    SendExp,
    SendGift,
    Ready
}