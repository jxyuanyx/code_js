export interface IBaseGameScene{


}
