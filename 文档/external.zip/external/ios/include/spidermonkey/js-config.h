#if defined(__LP64__) && __LP64__
#include"js-config-64.h"
#else
#include"js-config-32.h"
#endif
